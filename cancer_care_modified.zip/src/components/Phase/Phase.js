import React from "react";
import "./Phase.css";
const Phase = () => {
  return (
    <div className="Phase">
      <span>
        PHASE 2:
        <br />
        -Widget Sorting
        <br />
        -Training Date
      </span>
    </div>
  );
};

export default Phase;
